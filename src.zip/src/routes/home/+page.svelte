<script>

</script>

  
  <div class="home">
      
    <h1 style="margin-bottom: 50px;">Home Page</h1>
    <h3>More content goes here...</h3>

  </div>
  
<style>
    /* Set width to 100% and use flex display for horizontal alignment */
    .home {
        width: 100%;
        text-align: center;
        display: block;
        justify-content: space-around; /* To evenly space the tab links */
    }
</style>
